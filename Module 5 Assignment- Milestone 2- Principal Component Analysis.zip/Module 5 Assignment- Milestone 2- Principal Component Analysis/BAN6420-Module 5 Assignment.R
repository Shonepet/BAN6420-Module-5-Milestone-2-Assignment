library(ggplot2)
library(dplyr)
library(caret)
library(mlbench)

# Load the dataset
data(BreastCancer, package = "mlbench")

# Remove the Id column, while ensuring Class is a factor
cancer_data <- BreastCancer %>%
  select(-Id) %>%
  mutate(Class = as.factor(Class))

# Remove all rows with NA
cancer_data <- na.omit(cancer_data)

# Convert to numeric for PCA while excluding Class
numeric_data <- cancer_data %>%
  select(-Class) %>%
  mutate(across(everything(), ~ as.numeric(as.character(.))))

# Standardize the numeric data
scaled_data <- scale(numeric_data)

# Perform the PCA
pca_result <- prcomp(scaled_data, center = TRUE, scale. = TRUE)
summary(pca_result)  

# First two principal components and add the Class
pca_data <- as.data.frame(pca_result$x[, 1:2])  
pca_data$Class <- cancer_data$Class  # Add the Class column for visualization
colnames(pca_data) <- c("PC1", "PC2", "Class")

# Visualizing the PCA result
ggplot(pca_data, aes(x = PC1, y = PC2, color = Class)) +
  geom_point(alpha = 0.5) +
  labs(title = "PCA of Breast Cancer Dataset",
       x = "Principal Component 1",
       y = "Principal Component 2") +
  theme_minimal()


# Load necessary libraries
library(ggplot2)
library(dplyr)
library(caret)
library(mlbench)

# Load the dataset
data(BreastCancer, package = "mlbench")

# Remove the Id column while ensuring Class is a factor
cancer_data <- BreastCancer %>%
  select(-Id) %>%
  mutate(Class = as.factor(Class))

# Remove all rows with NA
cancer_data <- na.omit(cancer_data)

# Convert to numeric for PCA while excluding Class
numeric_data <- cancer_data %>%
  select(-Class) %>%
  mutate(across(everything(), ~ as.numeric(as.character(.))))

# Standardizing the numeric data
scaled_data <- scale(numeric_data)

# Perform the PCA
pca_result <- prcomp(scaled_data, center = TRUE, scale. = TRUE)

# First two principal components and add the Class
pca_data <- as.data.frame(pca_result$x[, 1:2])  
pca_data$Class <- cancer_data$Class  # Add the Class column for visualization

# Training and testing sets
set.seed(123)  
train_index <- createDataPartition(pca_data$Class, p = 0.7, list = FALSE)
train_data <- pca_data[train_index, ]
test_data <- pca_data[-train_index, ]

# Logistic Regression Model
logistic_model <- glm(Class ~ PC1 + PC2, data = train_data, family = binomial)

# Summarizing the model
summary(logistic_model)

# Predictions on the test set
predicted_probabilities <- predict(logistic_model, newdata = test_data, type = "response")
predicted_classes <- ifelse(predicted_probabilities > 0.5, "malignant", "benign")

# Confusion matrix
confusion_matrix <- confusionMatrix(factor(predicted_classes, levels = levels(test_data$Class)), test_data$Class)

# Print the confusion matrix and accuracy
print(confusion_matrix)
